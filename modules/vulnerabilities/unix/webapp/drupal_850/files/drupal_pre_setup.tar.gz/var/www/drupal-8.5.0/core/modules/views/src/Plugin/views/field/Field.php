<?php

namespace Drupal\views\Plugin\views\field;

/**
 * A stub class to provide backward compatibility for EntityField.
 *
 * @deprecated in Drupal 8.3.x and will be removed before 9.0.0
 *   Use \Drupal\views\Plugin\views\field\EntityField instead.
 */
class Field extends EntityField {

}
