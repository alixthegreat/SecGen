<?php

namespace Drupal\views\Plugin\views;

use Drupal\Component\Plugin\PluginInspectionInterface;

/**
 * @deprecated as of Drupal 8.3.x, will be removed in Drupal 9.0.0
 */
interface PluginInterface extends PluginInspectionInterface {

}
