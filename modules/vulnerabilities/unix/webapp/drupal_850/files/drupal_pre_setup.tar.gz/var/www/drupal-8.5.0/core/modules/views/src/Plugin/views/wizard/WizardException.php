<?php

namespace Drupal\views\Plugin\views\wizard;

/**
 * A custom exception class for our errors.
 */
class WizardException extends \Exception {

}
